create table Employee_XBBNHBG(emp_id int primary key,emp_name varchar(120),dob date,designation varchar(120),dept_id int references department_XBBNHBG);
create table Department_XBBNHBG(dept_id int primary key,dept_name varchar(120) );
insert into DEPARTMENT_XBBNHBG values(1,'wealth');
insert into EMPLOYEE_XBBNHBG values(11,'janani','1995-12-25','intern',1);
select * from Employee_XBBNHBG natural join Department_XBBNHBG where emp_id=11;