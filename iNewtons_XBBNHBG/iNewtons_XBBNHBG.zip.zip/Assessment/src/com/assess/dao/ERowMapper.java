package com.assess.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.assess.bean.Employee;

public class ERowMapper implements RowMapper<Employee> {

	@Override
	public Employee mapRow(ResultSet rs, int rowNum) throws SQLException {
		// TODO Auto-generated method stub
		System.out.println("inside");
		Employee e=new Employee();
		
			
		
		e.setEmp_id(rs.getInt(2));
		e.setEmp_name(rs.getString(3));
		e.setDob(rs.getString(4));
		e.setDesignation(rs.getString(5));
		e.setDept_id(rs.getInt(1));
		e.setDept_name(rs.getString(6));
		
		return e;
	}

}
