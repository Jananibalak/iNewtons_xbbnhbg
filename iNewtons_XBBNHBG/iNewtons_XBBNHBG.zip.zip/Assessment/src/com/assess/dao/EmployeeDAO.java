package com.assess.dao;

import java.sql.Types;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.support.JdbcDaoSupport;
import org.springframework.stereotype.Component;

import com.assess.bean.Employee;
@Component
public class EmployeeDAO  extends JdbcDaoSupport implements IEmployeeDAO{

	@Autowired
	public EmployeeDAO(DataSource dataSource)
	{
		setDataSource(dataSource);
	}
	@Override
	public Employee viewDetails(int empId) {
		// TODO Auto-generated method stub
		System.out.println("******************"+empId);
		try{
	     Employee e=getJdbcTemplate().queryForObject("select * from Employee_XBBNHBG natural join Department_XBBNHBG where emp_id="+empId,new ERowMapper());
	     return e;
		}
		catch(EmptyResultDataAccessException e )
		{
			Employee e1=new Employee();
			e1.setEmp_name("no such employee");
			return e1;
		}
	     
	}
    public int checkDept(int did)
    {
    	int i=getJdbcTemplate().queryForObject("select count(*) from Department_XBBNHBG where dept_id="+did,new DRowMapper());
    	return i;
    }
    public int checkEmp(int eid)
    {
    	int i=getJdbcTemplate().queryForObject("select count(*) from Employee_XBBNHBG where emp_id="+eid,new DRowMapper());
    	return i;
    }
	@Override
	public String insertDetails(Employee e) {
		// TODO Auto-generated method stub
		int r=checkDept(e.getDept_id());
		System.out.println("*******r");
		int result=0;
		if(r==-1)
		{
		result=getJdbcTemplate().update("insert into Department_XBBNHBG values(?,?)",new Object[]{e.getDept_id(),e.getDept_name()},new int[]{Types.INTEGER,Types.VARCHAR});
		}
		int result2=insertEmp(e);
		if(result==1 && result2==1 || r==1 && result2==1 )
			return "Inserted";
		else if(result==1 && result2==-1 || r==1 && result2==-1 )
			return "Already Inserted";
		else
			return "Not inserted";
	}
	
	public int insertEmp(Employee e)
	{
		int r=checkEmp(e.getEmp_id());
		System.out.println("*******r");
		if(r==-1){
		int result=getJdbcTemplate().update("insert into Employee_XBBNHBG values(?,?,?,?,?)",new Object[]{e.getEmp_id(),e.getEmp_name(),e.getDob(),e.getDesignation(),e.getDept_id()},new int[]{Types.INTEGER,Types.VARCHAR,Types.DATE,Types.VARCHAR,Types.INTEGER});
		
		return result;
		}
		else
			return -1;
		
	}
	

}
