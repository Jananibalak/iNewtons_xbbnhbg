package com.assess.dao;

import com.assess.bean.Employee;

public interface IEmployeeDAO {

	Employee viewDetails(int empId);
	String insertDetails(Employee e);
}
